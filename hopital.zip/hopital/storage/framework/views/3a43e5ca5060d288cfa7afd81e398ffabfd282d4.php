<?php $__env->startSection('content'); ?>
<div class="container">
<a href="/patient/create">  <button type="button" class="btn btn-outline-primary">Ajouter un Patient</button>
</a>
<br>
<br>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nome & Prenom</th>
      <th scope="col">Interlocuteur</th>
      <th scope="col">Role</th>
      <th scope="col">Date de naissance</th>
      <th scope="col">Telephone</th>
      <th scope="col"></th>
      <th scope="col"></th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th scope="row"><?php echo e($patient->id); ?></th>
        <td><?php echo e($patient->nom); ?> <?php echo e($patient->prenom); ?></td>
        <td><?php echo e($patient->responsable_full_name); ?> </td>
        <td><?php echo e($patient->responsable); ?> </td>
        <td><?php echo e($patient->naissance); ?> </td>
        <td><?php echo e($patient->telephone); ?></td>
        <td>
          <a href="#"><img src="<?php echo e(URL::asset('/img/info.png')); ?>" alt="profile Pic" data-toggle="modal" data-target="#info<?php echo e($patient->id); ?>" ></a>
          <!-- Modal Info-->
          <div class="modal fade" id="info<?php echo e($patient->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">
                    <?php if($patient->sexe == 'F'): ?>
                      <img class="img "    src="<?php echo e(URL::asset('/img/girl.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
                    <?php else: ?>
                      <img class="img "    src="<?php echo e(URL::asset('/img/boy.png')); ?>" style="width:50px;height:50px"       alt="Card image cap">
                    <?php endif; ?>
                      <?php echo e($patient->nom); ?> <?php echo e($patient->prenom); ?>

                   </h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                        

                          <div class="row">
                              <div class="col-6">
                                    <h5>Cin</h5>
                              </div>
                              <div class="col-6">
                                  <h6><?php echo e($patient->responsable_cin); ?></h6>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-6">
                                    <h5>Adresse</h5>
                              </div>
                              <div class="col-6">
                                  <h6><?php echo e($patient->adresse); ?></h6>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-6">
                                    <h5>Rang Famille</h5>
                              </div>
                              <div class="col-6">
                                  <h6><?php echo e($patient->rang_famille); ?></h6>
                              </div>
                          </div>

                          <div class="row">
                              <div class="col-6">
                                    <h5>Nombre des fréres</h5>
                              </div>
                              <div class="col-6">
                                  <h6><?php echo e($patient->nbre_fr_sr); ?></h6>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-6">
                                    <h5>Garde</h5>
                              </div>
                              <div class="col-6">
                                  <h6><?php echo e($patient->garde); ?></h6>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-2">
                                <img class="img "    src="<?php echo e(URL::asset('/img/letter.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
                              </div>
                              <div class="col-10">
                                  <h6><?php echo e($patient->lettre); ?></h6>
                              </div>
                          </div>

                          
                </div>

              </div>
            </div>
          </div>
            
        </td>
        <td>
          <a href="#"><img src="<?php echo e(URL::asset('/img/calendar.png')); ?>" alt="profile Pic" data-toggle="modal" data-target="#myModal<?php echo e($patient->id); ?>" ></a>
          <!-- Modal RDV-->
            <div class="modal fade" id="myModal<?php echo e($patient->id); ?>" >
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Ajouter rendez-vous</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

                  </div>
                  <div class="modal-body">
                    <form class="form-horizontal" action ="<?php echo e(url('rende')); ?>"  method="post" id="form<?php echo e($patient->id); ?>">
                      <?php echo e(csrf_field()); ?>

                        <fieldset>
                        <!-- Password input-->
                        <div class="form-group">
                          <label class="col-lg-4 control-label" for="passwordinput" >Date</label>
                          <div class="col-md-12">
                            <input required name="date" type="date" placeholder="" class="form-control input-md">
                          </div>
                        </div>

                        <!-- Text input-->
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="textinput">Time</label>
                          <div class="col-12">
                            <input required class="form-control" name="time" type="time" value="10:05:00" id="example-time-input">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="col-md-4 control-label" for="textinput">Valeur</label>
                          <div class="col-12">


                          <?php if(count($patient->rdv)): ?>
                              <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($k->patient_id == $patient->id): ?>
                              <input required class="form-control" type="number" value="<?php echo e($k->valeur); ?>" name="valeur">
                              <small id="passwordHelpInline" class="text-muted">
                                  nombre des anciens rendez-vous  <b><?php echo e($k->nbr); ?></b> / Etape  <?php echo e($k->etape); ?>

                                </small>
                              <?php break; ?>;

                              
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                        <?php else: ?>
                            <input required class="form-control" type="number" name="valeur" placeholder="0">
                            <?php endif; ?>

                            </div>
                        </div>


          <div class="form-group">

    <label class="col-md-4 control-label" for="exampleFormControlSelect1">Etape  Traitement</label>
    <div class="col-12">
      <?php if(count($patient->rdv)): ?>
          <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(($k->patient_id == $patient->id)&&($k->nbr == $k->valeur)): ?>
                <input class="form-control " id="disabledInput" type="text" placeholder="Etape" value="<?php echo e($k->etape+1); ?>" name="etape"  >
                <?php break; ?>;
              <?php elseif(($k->patient_id == $patient->id)&&($k->nbr < $k->valeur)): ?>
                <input class="form-control" id="disabledInput" type="text" placeholder="Etape" value="<?php echo e($k->etape); ?>" name="etape"  >
                <?php break; ?>;

              <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    <?php else: ?>
      <input class="form-control" id="disabledInput" type="text" placeholder="Etape" value="1" name="etape"  >
    <?php endif; ?>
  </div>
  </div>
                        </fieldset>
                        <input type="hidden" name="id_patient" value="<?php echo e($patient->id); ?>"/>
                      </form>

                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
                    <button type="submit" form="form<?php echo e($patient->id); ?>" class="btn btn-primary">Ajouter</button>
                  </div>
                </div>
              </div>
            </div>
            
        </td>

        <td>
          <a href="<?php echo e(url('patient/'.$patient->id.'/edit')); ?>">
            <button type="button" name="button">
              <img src="<?php echo e(URL::asset('/img/wrench.png')); ?>" alt="profile Pic" >
            </button>
            </a>
        </td>
        <td>
          <form class="" action="<?php echo e(url('patient/'.$patient->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

              <input type="hidden" name="_method" value="DELETE" >
              <a href="" >
                <button type="submit" name="button">
                  <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                </button>
              </a>
            </form>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>