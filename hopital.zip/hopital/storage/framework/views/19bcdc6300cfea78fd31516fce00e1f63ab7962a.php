<?php $__env->startSection('content'); ?>
<div class="container">

  <div class="row">
    <div class="col-10">
      <h3>Secretaires :</h3>
    </div>
    <div class="col-2">
      <a href="/secretaire/create">  <button type="button" class="btn btn-outline-primary">Nouveau</button></a>
    </div>

  </div>
<br>
<div class="row">
<?php $__currentLoopData = $secretaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secretaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="col-2">
      <center>
        <?php if($secretaire->sexe == 'F'): ?>
          <img class="img "    src="<?php echo e(URL::asset('/img/secretary.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
        <?php else: ?>
          <img class="img "    src="<?php echo e(URL::asset('/img/boss.png')); ?>" style="width:50px;height:50px"       alt="Card image cap">
        <?php endif; ?>
      </center>
    </div>
    <div class="col-10">
      <h5 class=""><?php echo e($secretaire->nom); ?> <?php echo e($secretaire->prenom); ?> </h5>
      <h6><img class="img"    src="<?php echo e(URL::asset('/img/smartphone.png')); ?>"       alt="Card image cap"><?php echo e($secretaire->telephone); ?></h6>
      <h6><img class="img"    src="<?php echo e(URL::asset('/img/gmail.png')); ?>"       alt="Card image cap"> <?php echo e($secretaire->user->email); ?></h6>
      <!-- Modal -->
<div class="modal fade" id="info<?php echo e($secretaire->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">
          <?php if($secretaire->sexe == 'F'): ?>
            <img class="img "    src="<?php echo e(URL::asset('/img/secretary.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
          <?php else: ?>
            <img class="img "    src="<?php echo e(URL::asset('/img/boss.png')); ?>" style="width:50px;height:50px"       alt="Card image cap">
          <?php endif; ?>
            <?php echo e($secretaire->nom); ?> <?php echo e($secretaire->prenom); ?>

         </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              

                <div class="row">
                    <div class="col-6">
                          <h5>Cin</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($secretaire->cin); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Adresse</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($secretaire->adrresse); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Date de début</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($secretaire->date_debut); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Date de naissance</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($secretaire->naissance); ?></h6>
                    </div>
                </div>

                
      </div>

    </div>
  </div>
</div>
      <hr>
      <div class="row">
        <div class="col-4">
            <a href="#"><img src="<?php echo e(URL::asset('/img/info.png')); ?>" alt="profile Pic" data-toggle="modal" data-target="#info<?php echo e($secretaire->id); ?>"></a>
        </div>
        <div class="col-4">
          <a href="<?php echo e(url('secretaire/'.$secretaire->id.'/edit')); ?>">
            <button type="button" name="button">
              <img src="<?php echo e(URL::asset('/img/wrench.png')); ?>" alt="profile Pic" >
            </button>
            </a>
        </div>
        <div class="col-4">
          <form class="" action="<?php echo e(url('secretaire/'.$secretaire->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

              <input type="hidden" name="_method" value="DELETE" >
              <a href="" >
                <button type="submit" name="button">
                  <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                </button>
              </a>
            </form>
        </div>
      </div>
    </div>
  </div>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br>
<hr>

<div class="row">
  <div class="col-10">
    <h3>Techniciens :</h3>
  </div>
  <div class="col-2">
    <a href="/technicien/create">  <button type="button" class="btn btn-outline-primary">Nouveau</button></a>
  </div>
</div>
<br>
<div class="row">
<?php $__currentLoopData = $techniciens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $technicien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="col-2">
      <center>
        <?php if($technicien->sexe == 'F'): ?>
          <img class="img "    src="<?php echo e(URL::asset('/img/doctor.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
        <?php else: ?>
          <img class="img "    src="<?php echo e(URL::asset('/img/doctor_male.png')); ?>" style="width:50px;height:50px"       alt="Card image cap">
        <?php endif; ?>
      </center>
    </div>
    <div class="col-10">
      <h5 class=""><?php echo e($technicien->nom); ?> <?php echo e($technicien->prenom); ?> </h5>
      <h6><img class="img"    src="<?php echo e(URL::asset('/img/smartphone.png')); ?>"       alt="Card image cap"><?php echo e($technicien->telephone); ?></h6>
      <h6><img class="img"    src="<?php echo e(URL::asset('/img/gmail.png')); ?>"       alt="Card image cap"> <?php echo e($technicien->user->email); ?></h6>
      <!-- Modal -->
<div class="modal fade" id="info<?php echo e($technicien->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">
          <?php if($technicien->sexe == 'F'): ?>
            <img class="img "    src="<?php echo e(URL::asset('/img/doctor.png')); ?>" style="width:50px;height:50px"   alt="Card image cap">
          <?php else: ?>
            <img class="img "    src="<?php echo e(URL::asset('/img/doctor_male.png')); ?>" style="width:50px;height:50px"       alt="Card image cap">
          <?php endif; ?>
            <?php echo e($technicien->nom); ?> <?php echo e($technicien->prenom); ?>

         </h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
              

                <div class="row">
                    <div class="col-6">
                          <h5>Cin</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($technicien->cin); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Adresse</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($technicien->adrresse); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Date de début</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($technicien->date_debut); ?></h6>
                    </div>
                </div>

                <div class="row">
                    <div class="col-6">
                          <h5>Date de naissance</h5>
                    </div>
                    <div class="col-6">
                        <h6><?php echo e($technicien->naissance); ?></h6>
                    </div>
                </div>

                
      </div>

    </div>
  </div>
</div>
      <hr>
      <div class="row">
        <div class="col-4">
            <a href="#"><img src="<?php echo e(URL::asset('/img/info.png')); ?>" alt="profile Pic" data-toggle="modal" data-target="#info<?php echo e($technicien->id); ?>"></a>
        </div>
        <div class="col-4">
          <a href="<?php echo e(url('technicien/'.$technicien->id.'/edit')); ?>">
            <button type="button" name="button">
              <img src="<?php echo e(URL::asset('/img/wrench.png')); ?>" alt="profile Pic" >
            </button>
            </a>
        </div>
        <div class="col-4">
          <form class="" action="<?php echo e(url('technicien/'.$technicien->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

              <input type="hidden" name="_method" value="DELETE" >
              <a href="" >
                <button type="submit" name="button">
                  <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                </button>
              </a>
            </form>
        </div>
      </div>
    </div>
  </div>
  <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>