<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-10">
      <h3>Tests</h3>
    </div>
    <div class="col-2">
      <!-- Button trigger modal -->
  <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#newtest">
    Nouveau
    </div>
</button>

  </div>
<br>
<?php if(count($tests)): ?>
    <div class="list-group">
        <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">

              <div class="col-10">
                <button type="button" class="list-group-item list-group-item-action" >  <?php echo e($test->nom); ?> / <?php echo e($test->category); ?>

                </button>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($item->test_id == $test->id): ?>
                      <div class="card-body">
                          <div class="row">
                              <div class="col-2">
                                <?php if($item->icon): ?>
                                  <img style="width:40px;height:40px;" src="<?php echo e(asset('storage/img/'.$item->icon)); ?>" alt="">
                                <?php else: ?>
                                  <img style="width:40px;height:40px;" src="<?php echo e(URL::asset('/img/to-do.png')); ?>" alt="">
                                <?php endif; ?>
                              </div>
                              <div class="col-9">
                                  <?php echo e($item->nom); ?>

                              </div>
                              <div class="col-1">
                                <form class="" action="<?php echo e(url('item/'.$item->id)); ?>" method="post">
                                      <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE" >
                                    <a href="" >
                                      <button type="submit" class="btn btn-outline-primary" name="button">
                                        <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                                      </button>
                                    </a>
                                  </form>
                              </div>
                          </div>
                      </div>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>



              
              <div class="col-1">
                <a href="#"><img src="<?php echo e(URL::asset('/img/to-do.png')); ?>" style="width:25px;height:25px" alt="profile Pic" data-toggle="modal" data-target="#info<?php echo e($test->id); ?>" ></a>
                <!-- Modal new item -->
                <div class="modal fade" id="info<?php echo e($test->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Nouveau Question</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        
                        <form class="form-horizontal" action ="<?php echo e(url('item')); ?>" enctype="multipart/form-data"  method="post" id="newitemform<?php echo e($test->id); ?>">
                          <?php echo e(csrf_field()); ?>

                            <!-- Password input-->
                            <div class="form-group">
                              <label class="col-lg-4 control-label" for="passwordinput" >Nom</label>
                              <div class="col-md-12">
                                <input required name="nom" type="text" placeholder="Nom du Test" class="form-control input-md">
                              </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                              <label class="col-md-4 control-label" for="textinput">Icon</label>
                              <div class="col-12">
                                <input  class="form-control" name="icon" type="file"  placeholder="icon du question"  id="example-time-input">
                              </div>
                            </div>

                            <input type="hidden" name="test_id" value="<?php echo e($test->id); ?>"/>

                          </form>
                        
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        <button type="submit" form="newitemform<?php echo e($test->id); ?>" class="btn btn-primary">Ajouter</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-1">
                <form class="" action="<?php echo e(url('test/'.$test->id)); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="DELETE" >
                    <a href="" >
                      <button type="submit" name="button">
                        <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                      </button>
                    </a>
                  </form>
              </div>

            </div>
              <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php else: ?>
  <h6>Pas encours des Tests</h6>
<?php endif; ?>

</div>
<!-- Modal new test -->
<div class="modal fade" id="newtest" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Nouveau Test</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
        <form class="form-horizontal" action ="<?php echo e(url('test')); ?>"  method="post" id="newtestform">
          <?php echo e(csrf_field()); ?>

            <!-- Password input-->
            <div class="form-group">
              <label class="col-lg-4 control-label" for="passwordinput" >Nom</label>
              <div class="col-md-12">
                <input required name="nom" type="text" placeholder="Nom du Test" class="form-control input-md">
              </div>
            </div>

            <!-- Text input-->
            <div class="form-group">
              <label class="col-md-4 control-label" for="textinput">Catégorie</label>
              <div class="col-12">
                <input required class="form-control" name="category" type="text"  placeholder="Categorie de test"  id="example-time-input">
              </div>
            </div>


          </form>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        <button type="submit" form="newtestform" class="btn btn-primary">Ajouter</button>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>