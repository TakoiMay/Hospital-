<?php $__env->startSection('content'); ?>
<div class="container" id="app">
  <div class="row">
    <div class="col-9">
      <h3>Tests</h3>
      <br>
      <div class="row">
        
        <?php if(count($exams)>0 ): ?>
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Score</th>
                <th scope="col">Tech</th>
                <th scope="col">Examen</th>
                <th scope="col">Date</th>
                <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
            
           <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($exam->rdv_id == $id): ?>
               <tr>
                 <th scope="row"><?php echo e($exam->id); ?></th>
                 <td><?php echo e($exam->score); ?> / <?php echo e($exam->max); ?></td>
                 <td><?php echo e($exam->user->name); ?>  </td>
                 <td><?php echo e($exam->test->nom); ?> / <?php echo e($exam->test->category); ?>  </td>
                 <td><?php echo e($exam->created_at); ?></td>
                 <td>
                   <form class="" action="<?php echo e(url('exam/'.$exam->id)); ?>" method="post">
                         <?php echo e(csrf_field()); ?>

                       <input type="hidden" name="_method" value="DELETE" >
                       <a href="" >
                         <button type="submit" class="btn btn-outline-primary" name="button">
                           <img src="<?php echo e(URL::asset('/img/garbage.png')); ?>" alt="profile Pic" >
                         </button>
                       </a>
                     </form>
                 </td>
               </tr>
             <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        <?php else: ?>
          <h6>0 test a été affecté</h6>
        <?php endif; ?>
      </div>
    </div>
    <div class="col-3">
        <div class="list-group" >
           <h6>Faire un test :</h6>
          <?php if(count($tests)): ?>
            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <button class="list-group-item list-group-item-action" type="button" data-toggle="modal" data-target="#info<?php echo e($test->id); ?>" type="button"> <?php echo e($test->nom); ?> / <?php echo e($test->category); ?></button>
                <!-- Modal -->
                <div class="modal fade" id="info<?php echo e($test->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Examen</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                              <?php if(count($test->item)): ?>
                                <table class="table table-striped">
                                                         <thead>
                                                           <tr>
                                                             <th scope="col">#</th>
                                                             <th scope="col">Test</th>
                                                             <th scope="col">Réponse</th>
                                                           </tr>
                                                         </thead>
                                                         <tbody>
                                                              <!-- Test -->
                                                              <?php $__currentLoopData = $test->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                             <tr>
                                                               <th scope="row"><?php echo e($item->nom); ?></th>
                                                               <td>
                                                                 <?php if($item->icon): ?>
                                                                   <img style="width:40px;height:40px;" src="<?php echo e(asset('storage/img/'.$item->icon)); ?>" alt="">
                                                                 <?php else: ?>
                                                                   <img style="width:40px;height:40px;" src="<?php echo e(URL::asset('/img/to-do.png')); ?>" alt="">
                                                                 <?php endif; ?>
                                                               <td>
                                                            <input type="checkbox" name="" id="<?php echo e($item->id); ?>" onclick="calcul(this)" value="">
                                                               </td>
                                                             </tr>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                         </tbody>
                                  </table>
                                  
                                  <form class="form-horizontal" action ="<?php echo e(url('exam')); ?>" enctype="multipart/form-data"  method="post" id="form<?php echo e($test->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                      <!-- Password input-->
                                      <div class="input-group mb-3">
                                                  <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">
                                                      Score
                                                    </span>
                                                  </div>
                                                  <input type="number" class="form-control"  id="score_val" placeholder="0"  name="score" required />
                                                  </div>

                                      <input type="hidden" name="rdv_id" value="<?php echo e($id); ?>" name="rdv_id"/>
                                      <input type="hidden" name="test_id" value="<?php echo e($test->id); ?>" name="test_id"/>
                                      <input type="hidden" name="max" value="<?php echo e(count($test->item)*10); ?>" name="max"/>

                                    </form>

                              <?php else: ?>
                                <h6 class="text-primary">Ce Test n'a pas encore des elements</h6>
                              <?php endif; ?>

                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">fermer</button>
                            <button type="submit" form="form<?php echo e($test->id); ?>" class="btn btn-primary" >Ajouter</button>
                          </div>
                        </div>
                      </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <h4>Pas de Test</h4>
          <?php endif; ?>
        </div>
    </div>


  </div>
<br>


</div>
<script>
var score = 0;

function calcul(cb){
  if (cb.checked) {
    score += 10;
    document.getElementById("score_val").value = score;
  }
  else {
    score -=10;
    document.getElementById("score_val").value = score;
  }

}
function affiche(){
  document.getElementById("score_val").value = score;
}
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>