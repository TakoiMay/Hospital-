<?php $__env->startSection('content'); ?>
<div class="container">
  <form class="" action="<?php echo e(url('patient/'. $patient->id)); ?>" enctype="multipart/form-data" method="post">
    <input type="hidden" name="_method" value="PUT">
   <?php echo e(csrf_field()); ?>

   <h4><img src="<?php echo e(URL::asset('/img/parent.png')); ?>" alt="profile Pic" > <u>Interlocuteur</u></h4>
     <div class="form-group row">
      <label for="inputEmail3" class="col-sm-2 col-form-label">Nom & prénom</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="inputEmail3" placeholder="Nom et prenom" name="responsable_full_name" value="<?php echo e($patient->responsable_full_name); ?>" required>
      </div>
     </div>
     
     <div class="form-group row">
      <label for="inputPassword3" class="col-sm-2 col-form-label">Cin</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="inputPassword3" placeholder="num carte d'identité" name="responsable_cin" value="<?php echo e($patient->responsable_cin); ?>" required>
      </div>
     </div>

  
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">Téléphone</label>
    <div class="col-sm-4">
      <input type="tele" class="form-control" id="inputPassword3" placeholder="+216" name="responsable_telephone" value="<?php echo e($patient->telephone); ?>" required>
    </div>
  </div>
  
  <div class="form-group row">
    <label for="inputPassword3" class="col-sm-2 col-form-label">lien paréntale</label>
    <div class="col-sm-4">
      <select required class="form-control" id="inlineFormCustomSelect" name="responsable"   >
         <option value="">Choose...</option>
         <option <?php if($patient->responsable == 'pére'): ?> selected <?php endif; ?> value="pére">Pére</option>
         <option <?php if($patient->responsable == 'mére'): ?> selected <?php endif; ?>  value="mére">Mére</option>
         <option <?php if($patient->responsable == 'oncle'): ?> selected <?php endif; ?> value="oncle">Oncle</option>
         <option <?php if($patient->responsable == 'tante'): ?> selected <?php endif; ?> value="tante">Tante</option>
         <option value="autre">autre</option>
       </select>
    </div>
  </div>


 
    <h4><img src="<?php echo e(URL::asset('/img/child.png')); ?>" alt="profile Pic" ><u>Patient</u></h4>
    
   <div class="form-row">
     <div class="form-group col-md-6">
       <label for="inputEmail4">Nom</label>
       <input type="text" class="form-control" id="nom" name="nom"  placeholder="Nom"  value="<?php echo e($patient->nom); ?>" required>
     </div>
     <div class="form-group col-md-6">
       <label for="inputPassword4">Prenom</label>
       <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prenom" value="<?php echo e($patient->prenom); ?>" required>
     </div>
   </div>

 
   <div class="form-row">
     <div class="form-group col-md-6">
       <label for="inputZip">Date de naissance</label>
       <input type="date" class="form-control" id="naissance" name="naissance" value="<?php echo e($patient->naissance); ?>" required>
     </div>
     <div class="form-group col-md-6">
       <label for="inputAddress">Addresse</label>
       <input type="text" class="form-control" id="Address" name="addresse" placeholder="12 rue liberté Béja Tunis" value="<?php echo e($patient->adresse); ?>" required>
     </div>
   </div>

     
     <div class="form-row">
     <div class="form-group col-md-6">
       <label for="">Sexe</label>
             <div class="form-check form-check-inline">
             <input class="form-check-input" type="radio" name="sexe" id="inlineRadio1" value="F" <?php if($patient->sexe == 'F'): ?> checked <?php endif; ?>>
             <label class="form-check-label" for="inlineRadio1">Femme</label>
             </div>
             <div class="form-check form-check-inline">
             <input class="form-check-input" type="radio" name="sexe" id="inlineRadio2" value="H" <?php if($patient->sexe == 'H'): ?> checked <?php endif; ?>>
             <label class="form-check-label" for="inlineRadio2">Homme</label>
             </div>
     </div>
   </div>

   
     <div class="form-row">
       <div class="form-group col-md-4">
         <label for="rang">Rang (famille)</label>
         <input type="number" class="form-control" id="rang" name="rang_famille" value="<?php echo e($patient->rang_famille); ?>">
       </div>
       <div class="form-group col-md-4">
         <label for="inputAddress">Nbr (frére & Soeur)</label>
         <input type="number" class="form-control" id="Address" name="nbre_fr_sr" value="<?php echo e($patient->nbre_fr_sr); ?>" placeholder="nombre des fréres et soeurs">
       </div>
       <div class="form-group col-md-4">
         <label for="inputAddress">Garde</label>
         <input type="text" class="form-control" id="Address" name="garde" placeholder="garde" value="<?php echo e($patient->garde); ?>">
       </div>
     </div>
     
       <div class="form-row">
         <div class="form-group col-md-12">
           <label for="le">Lettre de loison</label>
           <textarea type="text" class="form-control" id="lettre" name="lettre"  required>
             <?php echo e($patient->lettre); ?>

             </textarea>
         </div>
       </div>
  <button type="submit" class="btn btn-success">Mise à jour</button>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>