
<script>
    export default {
        score() {
          alert("score");
        }
    }
</script>
